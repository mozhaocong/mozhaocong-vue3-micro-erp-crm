import { defineComponent } from 'vue'

export default defineComponent({
	name: 'basisPagePermissions',
	setup() {
		return () => <div>pagePermissions</div>
	},
})
