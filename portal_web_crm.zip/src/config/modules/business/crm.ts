export const crmOptObject: Config = {
	crmCategory: {
		0: '其他',
		1: 'luvme',
		2: 'HotBeauty',
		3: 'uwins',
		4: 'BQ',
		5: 'Naija',
	},
}
