let apiUrl = ''
const crm = 'http://crm_test.htwig.com'
const erp_test = 'http://erp_test.admin.htwig.com'
apiUrl = ''
apiUrl = crm
const erpUrl = erp_test
export { apiUrl, erpUrl }
