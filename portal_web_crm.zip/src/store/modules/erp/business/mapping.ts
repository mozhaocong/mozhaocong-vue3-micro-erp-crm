import { basicDataModule } from './index'

export const storeMapping: ObjectMap = {
	basicDataModule: basicDataModule,
}
